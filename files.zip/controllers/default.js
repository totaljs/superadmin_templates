exports.install = function() {
	ROUTE('+GET /');
};